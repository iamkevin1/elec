import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime
from PIL import Image
import os

# CSV file paths
READINGS_CSV = "electricity_readings.csv"
APPLIANCES_CSV = "appliances.csv"
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Load or create CSV files
def load_data():
    if not os.path.exists(READINGS_CSV):
        pd.DataFrame(columns=["timestamp", "reading_kwh", "image"]).to_csv(READINGS_CSV, index=False)
    if not os.path.exists(APPLIANCES_CSV):
        pd.DataFrame(columns=["appliance", "power_watt", "hours_per_day"]).to_csv(APPLIANCES_CSV, index=False)
    return pd.read_csv(READINGS_CSV), pd.read_csv(APPLIANCES_CSV)

# Save functions
def save_reading(timestamp, reading_kwh, image_file):
    df = pd.read_csv(READINGS_CSV)
    img_path = os.path.join(UPLOAD_DIR, image_file.name)
    with open(img_path, "wb") as f:
        f.write(image_file.getbuffer())
    df = pd.concat([df, pd.DataFrame([{"timestamp": timestamp, "reading_kwh": reading_kwh, "image": img_path}])])
    df.to_csv(READINGS_CSV, index=False)

def save_appliance(appliance, watt, hours):
    df = pd.read_csv(APPLIANCES_CSV)
    df = pd.concat([df, pd.DataFrame([{"appliance": appliance, "power_watt": watt, "hours_per_day": hours}])])
    df.to_csv(APPLIANCES_CSV, index=False)

# Load data
readings_df, appliances_df = load_data()

# Streamlit UI
st.set_page_config(page_title="Electricity Analyzer", layout="centered")
st.title("⚡ Electricity Reading and Analyzer")

menu = st.sidebar.radio("Select Option", ["1. Upload Reading", "2. View All Data", "3. Track & Analyze", "4. Appliance Estimator"])

# Upload Reading
if menu.startswith("1"):
    st.header("📷 Upload Electricity Reading")
    reading = st.number_input("Enter Reading (in kWh)", step=0.1)
    timestamp = st.datetime_input("Time of Reading", datetime.now())
    image_file = st.file_uploader("Upload Meter Image", type=["jpg", "png", "jpeg"])
    if st.button("Save Reading"):
        if image_file:
            save_reading(timestamp, reading, image_file)
            st.success("Reading saved successfully.")
        else:
            st.warning("Please upload an image.")

# View Data
elif menu.startswith("2"):
    st.header("📊 All Electricity Data")
    st.dataframe(readings_df)

# Track & Analyze
elif menu.startswith("3"):
    st.header("📈 Track Electricity Usage")
    if readings_df.empty:
        st.info("No readings available.")
    else:
        readings_df["timestamp"] = pd.to_datetime(readings_df["timestamp"])
        readings_df = readings_df.sort_values("timestamp")
        readings_df["difference"] = readings_df["reading_kwh"].diff().fillna(0)
        readings_df["date"] = readings_df["timestamp"].dt.date
        daily_usage = readings_df.groupby("date")["difference"].sum().reset_index()
        fig = px.line(daily_usage, x="date", y="difference", title="Daily Electricity Usage (kWh)")
        st.plotly_chart(fig, use_container_width=True)

# Appliance Estimator
elif menu.startswith("4"):
    st.header("🔌 Appliance Electricity Estimator")
    with st.form("appliance_form"):
        appliance = st.text_input("Appliance Name")
        watt = st.number_input("Power Rating (Watts)", min_value=1)
        hours = st.number_input("Hours Used Per Day", min_value=0.1)
        submitted = st.form_submit_button("Add Appliance")
        if submitted:
            save_appliance(appliance, watt, hours)
            st.success("Appliance added.")

    if not appliances_df.empty:
        appliances_df["daily_kwh"] = (appliances_df["power_watt"] * appliances_df["hours_per_day"]) / 1000
        st.dataframe(appliances_df)
        st.metric("Estimated Daily Consumption (kWh)", round(appliances_df["daily_kwh"].sum(), 2))
